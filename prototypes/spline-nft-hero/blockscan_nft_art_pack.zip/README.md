# BlockScan NFT Hero Art Pack

Nine 512×512 WebP images intended as local textures for the standalone Three.js hero prototype.

These are original, collection-neutral prototype artworks created for this BlockScan scene. They are not official CryptoPunks, Moonbirds, Nouns, Pudgy Penguins, etc.

Recommended usage:
- copy all `.webp` files into `prototypes/spline-nft-hero/public/nfts/`
- point `src/config/nfts.js` at the filenames listed in `manifest.json`
- keep the existing CanvasTexture fallback

Suggested slot mapping is included in `manifest.json`.
